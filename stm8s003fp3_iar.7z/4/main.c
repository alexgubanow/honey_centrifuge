#include "stm8s.h"


uint32_t time;
uint32_t pwm;
uint8_t buttonstate = 0;

void init_button();
void init_adc();
void init_pwm();
void init_timer();
void init_EXTI();


void init_button()
{
  GPIO_Init(GPIOA, GPIO_PIN_5, GPIO_MODE_IN_PU_IT);
}

void init_EXTI()
{
  EXTI_SetExtIntSensitivity(EXTI_PORT_GPIOA,EXTI_SENSITIVITY_FALL_ONLY); //��� 1�� ���� �� ����� ����������
  enableInterrupts(); //��������� ����������.
}

INTERRUPT_HANDLER(EXTI1_IRQHandler, 9)
{
 if (buttonstate==1)
 {
   buttonstate=0;
   pwm=0;
   /*timer stop*/
 }
 else{
   buttonstate=1;
   /*timer start*/
 }
 
 EXTI->CR1 = EXTI_CR1_RESET_VALUE;
}

void init_pwm (){

	  
}

void init_adc(){

}

void init_timer(){

}


int main(void)
{
	init_adc();
	init_button();
	init_EXTI();
	init_pwm();
        init_timer();
	
	while(1)
   {
     if (buttonstate==1)
     {
       /*TIM2->pwm;*/
     }
   }
}



