/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H__
#define __MAIN_H__

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Evalboard I/Os configuration */

#define ADC_PORT  (GPIOD)
#define ADC1_PIN  (GPIO_PIN_3)
#define ADC2_PIN  (GPIO_PIN_2)

#define BUTTON_PORT (GPIOA)
#define BUTTON_PIN  (GPIO_PIN_5)

#define PWM_PORT      (GPIOD)
#define PWM_PIN  (GPIO_PIN_4)

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Public functions ----------------------------------------------------------*/

#endif /* __MAIN_H__ */